const cards = [
    {question: "Balance: C_2H_6 + O_2 → CO_2 + H_2O", answer: "2C_2H_6 + 7O_2 → 4CO_2 + 6H_2O"},
    {question: "5g H_2O to moles.", answer: "0.278"},
    {question: "Limiting reactant: 10g H_2 & 20g O_2.", answer: "O_2"},
    {question: "Yield H_2O from 4g H_2.", answer: "36"},
    {question: "Balance: Al + O_2 → Al_2O_3", answer: "4Al + 3O_2 → 2Al_2O_3"},
    {question: "22g CO_2 to moles.", answer: "0.5"},
    {question: "Limiting reactant: 15g Na & 25g Cl_2.", answer: "Cl_2"},
    {question: "Yield CO_2 from 10g C.", answer: "36.65"},
    {question: "Balance: HCl + NaOH → NaCl + H_2O", answer: "HCl + NaOH → NaCl + H_2O"},
    {question: "10g NaCl to moles.", answer: "0.171"},
    {question: "Limiting reactant: 8g CH_4 & 16g O_2.", answer: "O_2"},
    {question: "Yield NaCl from 5g HCl.", answer: "8"},
    {question: "Percent yield: 3.5g/4g.", answer: "87.5"},
    {question: "Percent yield: 8g/10g.", answer: "80"},
    {question: "Percent yield: 2g/2.5g.", answer: "80"},
    // Add more cards as needed
];

let currentCardIndex = 0;
let currentPlayer = 0;
let players = [];

document.getElementById('startGame').addEventListener('click', startGame);
document.getElementById('nextTurn').addEventListener('click', nextTurn);

function startGame() {
    const playerCount = document.getElementById('players').value;
    players = Array.from({length: playerCount}, (_, i) => ({id: i, score: 0, altitude: 5}));
    document.getElementById('gameBoard').classList.remove('hidden');
    document.getElementById('startGame').classList.add('hidden');
    updatePlayerStatus();
    nextTurn();
}

function nextTurn() {
    if (currentCardIndex >= cards.length) {
        const winner = players.reduce((max, player) => (player.altitude > max.altitude ? player : max), players[0]);
        document.getElementById('winner').innerHTML = `Congratulations, Player ${winner.id + 1}! You made it to the airport first! 🛫`;
        document.getElementById('winner').classList.remove('hidden');
        document.getElementById('playerTurn').classList.add('hidden');
        document.getElementById('cardContainer').classList.add('hidden');
        document.getElementById('nextTurn').classList.add('hidden');
        return;
    }

    const card = cards[currentCardIndex];
    document.getElementById('playerTurn').innerHTML = `Player ${players[currentPlayer].id + 1}'s Turn`;
    document.getElementById('cardContainer').innerHTML = `
        <div class="card">
            <p>${card.question}</p>
            <input type="text" id="answerInput" placeholder="Your Answer">
            <button onclick="checkAnswer()">Submit</button>
        </div>`;
    currentCardIndex++;
    document.getElementById('nextTurn').classList.remove('hidden');
}

function checkAnswer() {
    const answer = document.getElementById('answerInput').value.trim();
    const correctAnswer = cards[currentCardIndex - 1].answer;

    if (answer === correctAnswer) {
        players[currentPlayer].altitude += 1;
    } else {
        players[currentPlayer].altitude -= 1;
    }

    updatePlayerStatus();

    if (players[currentPlayer].altitude <= 0) {
        document.getElementById('winner').innerHTML = `Player ${players[currentPlayer].id + 1} has crashed! 🛬`;
        document.getElementById('winner').classList.remove('hidden');
        document.getElementById('playerTurn').classList.add('hidden');
        document.getElementById('cardContainer').classList.add('hidden');
        document.getElementById('nextTurn').classList.add('hidden');
        return;
    }

    currentPlayer = (currentPlayer + 1) % players.length;
}

function updatePlayerStatus() {
    const statusContainer = document.getElementById('playerStatus');
    statusContainer.innerHTML = players.map(player => `
        <div class="player">
            Player ${player.id + 1}: Altitude ${player.altitude}
        </div>`).join('');
}
